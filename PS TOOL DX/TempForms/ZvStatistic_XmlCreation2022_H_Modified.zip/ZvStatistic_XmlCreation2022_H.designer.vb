﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ZvStatistic_XmlCreation2022_H
    Inherits DevExpress.XtraEditors.XtraUserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ZvStatistic_XmlCreation2022_H))
        Me.AbacusFilesRecreationLayoutControl1ConvertedLayout = New DevExpress.XtraLayout.LayoutControl()
        Me.ClearAll_btn = New DevExpress.XtraEditors.SimpleButton()
        Me.SelectAll_btn = New DevExpress.XtraEditors.SimpleButton()
        Me.ZVS52_CheckEdit = New DevExpress.XtraEditors.CheckEdit()
        Me.ZVS42_CheckEdit = New DevExpress.XtraEditors.CheckEdit()
        Me.ZVS41_CheckEdit = New DevExpress.XtraEditors.CheckEdit()
        Me.ZVS3_CheckEdit = New DevExpress.XtraEditors.CheckEdit()
        Me.ZVS2_CheckEdit = New DevExpress.XtraEditors.CheckEdit()
        Me.ZVS1_CheckEdit = New DevExpress.XtraEditors.CheckEdit()
        Me.PictureEdit1 = New DevExpress.XtraEditors.PictureEdit()
        Me.ProgressPanel1 = New DevExpress.XtraWaitForm.ProgressPanel()
        Me.ZvMeldeschemas_SearchLookUpEdit = New DevExpress.XtraEditors.TextEdit()
        Me.ZvMeldeperiod_ComboboxEdit = New DevExpress.XtraEditors.TextEdit()
        Me.ZvMeldejahr_DateEdit = New DevExpress.XtraEditors.TextEdit()
        Me.ZVS6_CheckEdit = New DevExpress.XtraEditors.CheckEdit()
        Me.ZVS51_CheckEdit = New DevExpress.XtraEditors.CheckEdit()
        Me.LayoutControlGroup1 = New DevExpress.XtraLayout.LayoutControlGroup()
        Me.SearchLookUpEdit1item = New DevExpress.XtraLayout.LayoutControlItem()
        Me.LayoutControlItem1 = New DevExpress.XtraLayout.LayoutControlItem()
        Me.LayoutControlItem2 = New DevExpress.XtraLayout.LayoutControlItem()
        Me.LayoutControlItem4 = New DevExpress.XtraLayout.LayoutControlItem()
        Me.LayoutControlItem3 = New DevExpress.XtraLayout.LayoutControlItem()
        Me.LayoutControlItem5 = New DevExpress.XtraLayout.LayoutControlItem()
        Me.LayoutControlItem6 = New DevExpress.XtraLayout.LayoutControlItem()
        Me.LayoutControlItem7 = New DevExpress.XtraLayout.LayoutControlItem()
        Me.LayoutControlItem8 = New DevExpress.XtraLayout.LayoutControlItem()
        Me.LayoutControlItem9 = New DevExpress.XtraLayout.LayoutControlItem()
        Me.LayoutControlItem10 = New DevExpress.XtraLayout.LayoutControlItem()
        Me.LayoutControlItem11 = New DevExpress.XtraLayout.LayoutControlItem()
        Me.LayoutControlItem12 = New DevExpress.XtraLayout.LayoutControlItem()
        Me.LayoutControlItem14 = New DevExpress.XtraLayout.LayoutControlItem()
        Me.LayoutControlItem13 = New DevExpress.XtraLayout.LayoutControlItem()
        Me.ReportingDate_BarEditItem = New DevExpress.XtraBars.BarEditItem()
        Me.BarEditItem1 = New DevExpress.XtraBars.BarEditItem()
        CType(Me.AbacusFilesRecreationLayoutControl1ConvertedLayout, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.AbacusFilesRecreationLayoutControl1ConvertedLayout.SuspendLayout()
        CType(Me.ZVS52_CheckEdit.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ZVS42_CheckEdit.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ZVS41_CheckEdit.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ZVS3_CheckEdit.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ZVS2_CheckEdit.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ZVS1_CheckEdit.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureEdit1.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ZvMeldeschemas_SearchLookUpEdit.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ZvMeldeperiod_ComboboxEdit.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ZvMeldejahr_DateEdit.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ZVS6_CheckEdit.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ZVS51_CheckEdit.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LayoutControlGroup1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.SearchLookUpEdit1item, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LayoutControlItem1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LayoutControlItem2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LayoutControlItem4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LayoutControlItem3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LayoutControlItem5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LayoutControlItem6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LayoutControlItem7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LayoutControlItem8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LayoutControlItem9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LayoutControlItem10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LayoutControlItem11, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LayoutControlItem12, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LayoutControlItem14, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LayoutControlItem13, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'AbacusFilesRecreationLayoutControl1ConvertedLayout
        '
        Me.AbacusFilesRecreationLayoutControl1ConvertedLayout.Controls.Add(Me.ClearAll_btn)
        Me.AbacusFilesRecreationLayoutControl1ConvertedLayout.Controls.Add(Me.SelectAll_btn)
        Me.AbacusFilesRecreationLayoutControl1ConvertedLayout.Controls.Add(Me.ZVS52_CheckEdit)
        Me.AbacusFilesRecreationLayoutControl1ConvertedLayout.Controls.Add(Me.ZVS42_CheckEdit)
        Me.AbacusFilesRecreationLayoutControl1ConvertedLayout.Controls.Add(Me.ZVS41_CheckEdit)
        Me.AbacusFilesRecreationLayoutControl1ConvertedLayout.Controls.Add(Me.ZVS3_CheckEdit)
        Me.AbacusFilesRecreationLayoutControl1ConvertedLayout.Controls.Add(Me.ZVS2_CheckEdit)
        Me.AbacusFilesRecreationLayoutControl1ConvertedLayout.Controls.Add(Me.ZVS1_CheckEdit)
        Me.AbacusFilesRecreationLayoutControl1ConvertedLayout.Controls.Add(Me.PictureEdit1)
        Me.AbacusFilesRecreationLayoutControl1ConvertedLayout.Controls.Add(Me.ProgressPanel1)
        Me.AbacusFilesRecreationLayoutControl1ConvertedLayout.Controls.Add(Me.ZvMeldeschemas_SearchLookUpEdit)
        Me.AbacusFilesRecreationLayoutControl1ConvertedLayout.Controls.Add(Me.ZvMeldeperiod_ComboboxEdit)
        Me.AbacusFilesRecreationLayoutControl1ConvertedLayout.Controls.Add(Me.ZvMeldejahr_DateEdit)
        Me.AbacusFilesRecreationLayoutControl1ConvertedLayout.Controls.Add(Me.ZVS6_CheckEdit)
        Me.AbacusFilesRecreationLayoutControl1ConvertedLayout.Controls.Add(Me.ZVS51_CheckEdit)
        Me.AbacusFilesRecreationLayoutControl1ConvertedLayout.Dock = System.Windows.Forms.DockStyle.Fill
        Me.AbacusFilesRecreationLayoutControl1ConvertedLayout.Location = New System.Drawing.Point(0, 0)
        Me.AbacusFilesRecreationLayoutControl1ConvertedLayout.Name = "AbacusFilesRecreationLayoutControl1ConvertedLayout"
        Me.AbacusFilesRecreationLayoutControl1ConvertedLayout.OptionsCustomizationForm.DesignTimeCustomizationFormPositionAndSize = New System.Drawing.Rectangle(454, 0, 650, 400)
        Me.AbacusFilesRecreationLayoutControl1ConvertedLayout.Root = Me.LayoutControlGroup1
        Me.AbacusFilesRecreationLayoutControl1ConvertedLayout.Size = New System.Drawing.Size(579, 460)
        Me.AbacusFilesRecreationLayoutControl1ConvertedLayout.TabIndex = 1
        '
        'ClearAll_btn
        '
        Me.ClearAll_btn.ImageOptions.Image = CType(resources.GetObject("ClearAll_btn.ImageOptions.Image"), System.Drawing.Image)
        Me.ClearAll_btn.Location = New System.Drawing.Point(303, 389)
        Me.ClearAll_btn.Name = "ClearAll_btn"
        Me.ClearAll_btn.Size = New System.Drawing.Size(266, 22)
        Me.ClearAll_btn.StyleController = Me.AbacusFilesRecreationLayoutControl1ConvertedLayout
        Me.ClearAll_btn.TabIndex = 18
        Me.ClearAll_btn.Text = "Clear All"
        '
        'SelectAll_btn
        '
        Me.SelectAll_btn.ImageOptions.Image = CType(resources.GetObject("SelectAll_btn.ImageOptions.Image"), System.Drawing.Image)
        Me.SelectAll_btn.Location = New System.Drawing.Point(12, 389)
        Me.SelectAll_btn.Name = "SelectAll_btn"
        Me.SelectAll_btn.Size = New System.Drawing.Size(287, 22)
        Me.SelectAll_btn.StyleController = Me.AbacusFilesRecreationLayoutControl1ConvertedLayout
        Me.SelectAll_btn.TabIndex = 17
        Me.SelectAll_btn.Text = "Select All"
        '
        'ZVS52_CheckEdit
        '
        Me.ZVS52_CheckEdit.Location = New System.Drawing.Point(12, 345)
        Me.ZVS52_CheckEdit.Name = "ZVS52_CheckEdit"
        Me.ZVS52_CheckEdit.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ZVS52_CheckEdit.Properties.Appearance.ForeColor = System.Drawing.Color.Aqua
        Me.ZVS52_CheckEdit.Properties.Appearance.Options.UseFont = True
        Me.ZVS52_CheckEdit.Properties.Appearance.Options.UseForeColor = True
        Me.ZVS52_CheckEdit.Properties.Caption = "ZVS5.2 - Betrügerische Zahlungsvorgänge Nicht-Zahlungsdienstleister  - Kartenzahl" &
    "ungen"
        Me.ZVS52_CheckEdit.Size = New System.Drawing.Size(557, 18)
        Me.ZVS52_CheckEdit.StyleController = Me.AbacusFilesRecreationLayoutControl1ConvertedLayout
        Me.ZVS52_CheckEdit.TabIndex = 16
        '
        'ZVS42_CheckEdit
        '
        Me.ZVS42_CheckEdit.Location = New System.Drawing.Point(12, 301)
        Me.ZVS42_CheckEdit.Name = "ZVS42_CheckEdit"
        Me.ZVS42_CheckEdit.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ZVS42_CheckEdit.Properties.Appearance.ForeColor = System.Drawing.Color.Aqua
        Me.ZVS42_CheckEdit.Properties.Appearance.Options.UseFont = True
        Me.ZVS42_CheckEdit.Properties.Appearance.Options.UseForeColor = True
        Me.ZVS42_CheckEdit.Properties.Caption = "ZVS4.2 - Zahlungsvorgänge Nicht-Zahlungsdienstleister  - Kartenzahlungen"
        Me.ZVS42_CheckEdit.Size = New System.Drawing.Size(557, 18)
        Me.ZVS42_CheckEdit.StyleController = Me.AbacusFilesRecreationLayoutControl1ConvertedLayout
        Me.ZVS42_CheckEdit.TabIndex = 15
        '
        'ZVS41_CheckEdit
        '
        Me.ZVS41_CheckEdit.Location = New System.Drawing.Point(12, 279)
        Me.ZVS41_CheckEdit.Name = "ZVS41_CheckEdit"
        Me.ZVS41_CheckEdit.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ZVS41_CheckEdit.Properties.Appearance.ForeColor = System.Drawing.Color.Aqua
        Me.ZVS41_CheckEdit.Properties.Appearance.Options.UseFont = True
        Me.ZVS41_CheckEdit.Properties.Appearance.Options.UseForeColor = True
        Me.ZVS41_CheckEdit.Properties.Caption = "ZVS4.1 - Zahlungsvorgänge Nicht-Zahlungsdienstleister  - Ohne Kartenzahlungen"
        Me.ZVS41_CheckEdit.Size = New System.Drawing.Size(557, 18)
        Me.ZVS41_CheckEdit.StyleController = Me.AbacusFilesRecreationLayoutControl1ConvertedLayout
        Me.ZVS41_CheckEdit.TabIndex = 14
        '
        'ZVS3_CheckEdit
        '
        Me.ZVS3_CheckEdit.Location = New System.Drawing.Point(12, 257)
        Me.ZVS3_CheckEdit.Name = "ZVS3_CheckEdit"
        Me.ZVS3_CheckEdit.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ZVS3_CheckEdit.Properties.Appearance.ForeColor = System.Drawing.Color.Aqua
        Me.ZVS3_CheckEdit.Properties.Appearance.Options.UseFont = True
        Me.ZVS3_CheckEdit.Properties.Appearance.Options.UseForeColor = True
        Me.ZVS3_CheckEdit.Properties.Caption = "ZVS3 - Akzeptanzstellen für Zahlungskarten"
        Me.ZVS3_CheckEdit.Size = New System.Drawing.Size(557, 18)
        Me.ZVS3_CheckEdit.StyleController = Me.AbacusFilesRecreationLayoutControl1ConvertedLayout
        Me.ZVS3_CheckEdit.TabIndex = 13
        '
        'ZVS2_CheckEdit
        '
        Me.ZVS2_CheckEdit.Location = New System.Drawing.Point(12, 235)
        Me.ZVS2_CheckEdit.Name = "ZVS2_CheckEdit"
        Me.ZVS2_CheckEdit.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ZVS2_CheckEdit.Properties.Appearance.ForeColor = System.Drawing.Color.Aqua
        Me.ZVS2_CheckEdit.Properties.Appearance.Options.UseFont = True
        Me.ZVS2_CheckEdit.Properties.Appearance.Options.UseForeColor = True
        Me.ZVS2_CheckEdit.Properties.Caption = "ZVS2 - Zahlungskarten"
        Me.ZVS2_CheckEdit.Size = New System.Drawing.Size(557, 18)
        Me.ZVS2_CheckEdit.StyleController = Me.AbacusFilesRecreationLayoutControl1ConvertedLayout
        Me.ZVS2_CheckEdit.TabIndex = 12
        '
        'ZVS1_CheckEdit
        '
        Me.ZVS1_CheckEdit.Location = New System.Drawing.Point(12, 213)
        Me.ZVS1_CheckEdit.Name = "ZVS1_CheckEdit"
        Me.ZVS1_CheckEdit.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ZVS1_CheckEdit.Properties.Appearance.ForeColor = System.Drawing.Color.Aqua
        Me.ZVS1_CheckEdit.Properties.Appearance.Options.UseFont = True
        Me.ZVS1_CheckEdit.Properties.Appearance.Options.UseForeColor = True
        Me.ZVS1_CheckEdit.Properties.Caption = "ZVS1 - Institute, die Nicht- Zahlungsdienstleistern Zahlungsdienste anbieten"
        Me.ZVS1_CheckEdit.Size = New System.Drawing.Size(557, 18)
        Me.ZVS1_CheckEdit.StyleController = Me.AbacusFilesRecreationLayoutControl1ConvertedLayout
        Me.ZVS1_CheckEdit.TabIndex = 11
        '
        'PictureEdit1
        '
        Me.PictureEdit1.EditValue = CType(resources.GetObject("PictureEdit1.EditValue"), Object)
        Me.PictureEdit1.Location = New System.Drawing.Point(12, 12)
        Me.PictureEdit1.Name = "PictureEdit1"
        Me.PictureEdit1.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.[Auto]
        Me.PictureEdit1.Properties.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Stretch
        Me.PictureEdit1.Size = New System.Drawing.Size(557, 155)
        Me.PictureEdit1.StyleController = Me.AbacusFilesRecreationLayoutControl1ConvertedLayout
        Me.PictureEdit1.TabIndex = 8
        '
        'ProgressPanel1
        '
        Me.ProgressPanel1.Appearance.BackColor = System.Drawing.Color.Transparent
        Me.ProgressPanel1.Appearance.Options.UseBackColor = True
        Me.ProgressPanel1.AppearanceCaption.Font = New System.Drawing.Font("Calibri", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ProgressPanel1.AppearanceCaption.ForeColor = System.Drawing.Color.Navy
        Me.ProgressPanel1.AppearanceCaption.Options.UseFont = True
        Me.ProgressPanel1.AppearanceCaption.Options.UseForeColor = True
        Me.ProgressPanel1.Location = New System.Drawing.Point(12, 415)
        Me.ProgressPanel1.Name = "ProgressPanel1"
        Me.ProgressPanel1.Size = New System.Drawing.Size(557, 16)
        Me.ProgressPanel1.StyleController = Me.AbacusFilesRecreationLayoutControl1ConvertedLayout
        Me.ProgressPanel1.TabIndex = 7
        Me.ProgressPanel1.Text = "ProgressPanel1"
        Me.ProgressPanel1.Visible = False
        '
        'ZvMeldeschemas_SearchLookUpEdit
        '
        Me.ZvMeldeschemas_SearchLookUpEdit.EditValue = ""
        Me.ZvMeldeschemas_SearchLookUpEdit.Location = New System.Drawing.Point(12, 189)
        Me.ZvMeldeschemas_SearchLookUpEdit.Name = "ZvMeldeschemas_SearchLookUpEdit"
        Me.ZvMeldeschemas_SearchLookUpEdit.Properties.Appearance.Options.UseTextOptions = True
        Me.ZvMeldeschemas_SearchLookUpEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.ZvMeldeschemas_SearchLookUpEdit.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Yellow
        Me.ZvMeldeschemas_SearchLookUpEdit.Properties.AppearanceFocused.BackColor2 = System.Drawing.Color.Yellow
        Me.ZvMeldeschemas_SearchLookUpEdit.Properties.AppearanceFocused.ForeColor = System.Drawing.Color.Black
        Me.ZvMeldeschemas_SearchLookUpEdit.Properties.AppearanceFocused.Options.UseBackColor = True
        Me.ZvMeldeschemas_SearchLookUpEdit.Properties.AppearanceFocused.Options.UseForeColor = True
        Me.ZvMeldeschemas_SearchLookUpEdit.Properties.NullText = "[EditValue is null]"
        Me.ZvMeldeschemas_SearchLookUpEdit.Properties.ReadOnly = True
        Me.ZvMeldeschemas_SearchLookUpEdit.Properties.UseReadOnlyAppearance = False
        Me.ZvMeldeschemas_SearchLookUpEdit.Size = New System.Drawing.Size(221, 20)
        Me.ZvMeldeschemas_SearchLookUpEdit.StyleController = Me.AbacusFilesRecreationLayoutControl1ConvertedLayout
        Me.ZvMeldeschemas_SearchLookUpEdit.TabIndex = 0
        '
        'ZvMeldeperiod_ComboboxEdit
        '
        Me.ZvMeldeperiod_ComboboxEdit.Location = New System.Drawing.Point(237, 189)
        Me.ZvMeldeperiod_ComboboxEdit.Name = "ZvMeldeperiod_ComboboxEdit"
        Me.ZvMeldeperiod_ComboboxEdit.Properties.Appearance.Options.UseTextOptions = True
        Me.ZvMeldeperiod_ComboboxEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.ZvMeldeperiod_ComboboxEdit.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Yellow
        Me.ZvMeldeperiod_ComboboxEdit.Properties.AppearanceFocused.BackColor2 = System.Drawing.Color.Yellow
        Me.ZvMeldeperiod_ComboboxEdit.Properties.AppearanceFocused.ForeColor = System.Drawing.Color.Black
        Me.ZvMeldeperiod_ComboboxEdit.Properties.AppearanceFocused.Options.UseBackColor = True
        Me.ZvMeldeperiod_ComboboxEdit.Properties.AppearanceFocused.Options.UseForeColor = True
        Me.ZvMeldeperiod_ComboboxEdit.Properties.DisplayFormat.FormatString = "d"
        Me.ZvMeldeperiod_ComboboxEdit.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime
        Me.ZvMeldeperiod_ComboboxEdit.Properties.EditFormat.FormatString = "d"
        Me.ZvMeldeperiod_ComboboxEdit.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime
        Me.ZvMeldeperiod_ComboboxEdit.Properties.ReadOnly = True
        Me.ZvMeldeperiod_ComboboxEdit.Properties.UseReadOnlyAppearance = False
        Me.ZvMeldeperiod_ComboboxEdit.Size = New System.Drawing.Size(196, 20)
        Me.ZvMeldeperiod_ComboboxEdit.StyleController = Me.AbacusFilesRecreationLayoutControl1ConvertedLayout
        Me.ZvMeldeperiod_ComboboxEdit.TabIndex = 9
        '
        'ZvMeldejahr_DateEdit
        '
        Me.ZvMeldejahr_DateEdit.Location = New System.Drawing.Point(437, 189)
        Me.ZvMeldejahr_DateEdit.Name = "ZvMeldejahr_DateEdit"
        Me.ZvMeldejahr_DateEdit.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.[False]
        Me.ZvMeldejahr_DateEdit.Properties.Appearance.Options.UseTextOptions = True
        Me.ZvMeldejahr_DateEdit.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.ZvMeldejahr_DateEdit.Properties.AppearanceFocused.BackColor = System.Drawing.Color.Yellow
        Me.ZvMeldejahr_DateEdit.Properties.AppearanceFocused.BackColor2 = System.Drawing.Color.Yellow
        Me.ZvMeldejahr_DateEdit.Properties.AppearanceFocused.ForeColor = System.Drawing.Color.Black
        Me.ZvMeldejahr_DateEdit.Properties.AppearanceFocused.Options.UseBackColor = True
        Me.ZvMeldejahr_DateEdit.Properties.AppearanceFocused.Options.UseForeColor = True
        Me.ZvMeldejahr_DateEdit.Properties.DisplayFormat.FormatString = "yyyy"
        Me.ZvMeldejahr_DateEdit.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom
        Me.ZvMeldejahr_DateEdit.Properties.EditFormat.FormatString = "yyyy"
        Me.ZvMeldejahr_DateEdit.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Custom
        Me.ZvMeldejahr_DateEdit.Properties.Mask.EditMask = "\d{4}"
        Me.ZvMeldejahr_DateEdit.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx
        Me.ZvMeldejahr_DateEdit.Properties.ReadOnly = True
        Me.ZvMeldejahr_DateEdit.Properties.UseReadOnlyAppearance = False
        Me.ZvMeldejahr_DateEdit.Size = New System.Drawing.Size(132, 20)
        Me.ZvMeldejahr_DateEdit.StyleController = Me.AbacusFilesRecreationLayoutControl1ConvertedLayout
        Me.ZvMeldejahr_DateEdit.TabIndex = 10
        '
        'ZVS6_CheckEdit
        '
        Me.ZVS6_CheckEdit.Location = New System.Drawing.Point(12, 367)
        Me.ZVS6_CheckEdit.Name = "ZVS6_CheckEdit"
        Me.ZVS6_CheckEdit.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ZVS6_CheckEdit.Properties.Appearance.ForeColor = System.Drawing.Color.Aqua
        Me.ZVS6_CheckEdit.Properties.Appearance.Options.UseFont = True
        Me.ZVS6_CheckEdit.Properties.Appearance.Options.UseForeColor = True
        Me.ZVS6_CheckEdit.Properties.Caption = "ZVS6 - Zahlungsvorgänge Nicht-Zahlungsdienstleister  - Nach art des Terminals"
        Me.ZVS6_CheckEdit.Size = New System.Drawing.Size(557, 18)
        Me.ZVS6_CheckEdit.StyleController = Me.AbacusFilesRecreationLayoutControl1ConvertedLayout
        Me.ZVS6_CheckEdit.TabIndex = 16
        '
        'ZVS51_CheckEdit
        '
        Me.ZVS51_CheckEdit.Location = New System.Drawing.Point(12, 323)
        Me.ZVS51_CheckEdit.Name = "ZVS51_CheckEdit"
        Me.ZVS51_CheckEdit.Properties.Appearance.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ZVS51_CheckEdit.Properties.Appearance.ForeColor = System.Drawing.Color.Aqua
        Me.ZVS51_CheckEdit.Properties.Appearance.Options.UseFont = True
        Me.ZVS51_CheckEdit.Properties.Appearance.Options.UseForeColor = True
        Me.ZVS51_CheckEdit.Properties.Caption = "ZVS5.1 - Betrügerische Zahlungsvorgänge Nicht-Zahlungsdienstleister  - Ohne Karte" &
    "nzahlungen"
        Me.ZVS51_CheckEdit.Size = New System.Drawing.Size(557, 18)
        Me.ZVS51_CheckEdit.StyleController = Me.AbacusFilesRecreationLayoutControl1ConvertedLayout
        Me.ZVS51_CheckEdit.TabIndex = 16
        '
        'LayoutControlGroup1
        '
        Me.LayoutControlGroup1.EnableIndentsWithoutBorders = DevExpress.Utils.DefaultBoolean.[True]
        Me.LayoutControlGroup1.GroupBordersVisible = False
        Me.LayoutControlGroup1.Items.AddRange(New DevExpress.XtraLayout.BaseLayoutItem() {Me.SearchLookUpEdit1item, Me.LayoutControlItem1, Me.LayoutControlItem2, Me.LayoutControlItem4, Me.LayoutControlItem3, Me.LayoutControlItem5, Me.LayoutControlItem6, Me.LayoutControlItem7, Me.LayoutControlItem8, Me.LayoutControlItem9, Me.LayoutControlItem10, Me.LayoutControlItem11, Me.LayoutControlItem12, Me.LayoutControlItem14, Me.LayoutControlItem13})
        Me.LayoutControlGroup1.Name = "Root"
        Me.LayoutControlGroup1.Size = New System.Drawing.Size(581, 443)
        Me.LayoutControlGroup1.TextVisible = False
        '
        'SearchLookUpEdit1item
        '
        Me.SearchLookUpEdit1item.AppearanceItemCaption.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SearchLookUpEdit1item.AppearanceItemCaption.Options.UseFont = True
        Me.SearchLookUpEdit1item.AppearanceItemCaption.Options.UseTextOptions = True
        Me.SearchLookUpEdit1item.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.SearchLookUpEdit1item.Control = Me.ZvMeldeschemas_SearchLookUpEdit
        Me.SearchLookUpEdit1item.Location = New System.Drawing.Point(0, 159)
        Me.SearchLookUpEdit1item.Name = "SearchLookUpEdit1item"
        Me.SearchLookUpEdit1item.Size = New System.Drawing.Size(225, 42)
        Me.SearchLookUpEdit1item.Text = "ZV Statistik Schema"
        Me.SearchLookUpEdit1item.TextLocation = DevExpress.Utils.Locations.Top
        Me.SearchLookUpEdit1item.TextSize = New System.Drawing.Size(106, 15)
        '
        'LayoutControlItem1
        '
        Me.LayoutControlItem1.Control = Me.ProgressPanel1
        Me.LayoutControlItem1.Location = New System.Drawing.Point(0, 403)
        Me.LayoutControlItem1.Name = "LayoutControlItem1"
        Me.LayoutControlItem1.Size = New System.Drawing.Size(561, 20)
        Me.LayoutControlItem1.TextSize = New System.Drawing.Size(0, 0)
        Me.LayoutControlItem1.TextVisible = False
        '
        'LayoutControlItem2
        '
        Me.LayoutControlItem2.Control = Me.PictureEdit1
        Me.LayoutControlItem2.Location = New System.Drawing.Point(0, 0)
        Me.LayoutControlItem2.Name = "LayoutControlItem2"
        Me.LayoutControlItem2.Size = New System.Drawing.Size(561, 159)
        Me.LayoutControlItem2.TextSize = New System.Drawing.Size(0, 0)
        Me.LayoutControlItem2.TextVisible = False
        '
        'LayoutControlItem4
        '
        Me.LayoutControlItem4.AppearanceItemCaption.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LayoutControlItem4.AppearanceItemCaption.Options.UseFont = True
        Me.LayoutControlItem4.AppearanceItemCaption.Options.UseTextOptions = True
        Me.LayoutControlItem4.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.LayoutControlItem4.Control = Me.ZvMeldejahr_DateEdit
        Me.LayoutControlItem4.Location = New System.Drawing.Point(425, 159)
        Me.LayoutControlItem4.Name = "LayoutControlItem4"
        Me.LayoutControlItem4.Size = New System.Drawing.Size(136, 42)
        Me.LayoutControlItem4.Text = "Meldejahr"
        Me.LayoutControlItem4.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize
        Me.LayoutControlItem4.TextLocation = DevExpress.Utils.Locations.Top
        Me.LayoutControlItem4.TextSize = New System.Drawing.Size(57, 13)
        Me.LayoutControlItem4.TextToControlDistance = 5
        '
        'LayoutControlItem3
        '
        Me.LayoutControlItem3.AppearanceItemCaption.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LayoutControlItem3.AppearanceItemCaption.Options.UseFont = True
        Me.LayoutControlItem3.AppearanceItemCaption.Options.UseTextOptions = True
        Me.LayoutControlItem3.AppearanceItemCaption.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.LayoutControlItem3.Control = Me.ZvMeldeperiod_ComboboxEdit
        Me.LayoutControlItem3.Location = New System.Drawing.Point(225, 159)
        Me.LayoutControlItem3.Name = "LayoutControlItem3"
        Me.LayoutControlItem3.Size = New System.Drawing.Size(200, 42)
        Me.LayoutControlItem3.Text = "Meldeperiode"
        Me.LayoutControlItem3.TextAlignMode = DevExpress.XtraLayout.TextAlignModeItem.AutoSize
        Me.LayoutControlItem3.TextLocation = DevExpress.Utils.Locations.Top
        Me.LayoutControlItem3.TextSize = New System.Drawing.Size(77, 13)
        Me.LayoutControlItem3.TextToControlDistance = 5
        '
        'LayoutControlItem5
        '
        Me.LayoutControlItem5.Control = Me.ZVS1_CheckEdit
        Me.LayoutControlItem5.Location = New System.Drawing.Point(0, 201)
        Me.LayoutControlItem5.Name = "LayoutControlItem5"
        Me.LayoutControlItem5.Size = New System.Drawing.Size(561, 22)
        Me.LayoutControlItem5.TextSize = New System.Drawing.Size(0, 0)
        Me.LayoutControlItem5.TextVisible = False
        '
        'LayoutControlItem6
        '
        Me.LayoutControlItem6.Control = Me.ZVS2_CheckEdit
        Me.LayoutControlItem6.Location = New System.Drawing.Point(0, 223)
        Me.LayoutControlItem6.Name = "LayoutControlItem6"
        Me.LayoutControlItem6.Size = New System.Drawing.Size(561, 22)
        Me.LayoutControlItem6.TextSize = New System.Drawing.Size(0, 0)
        Me.LayoutControlItem6.TextVisible = False
        '
        'LayoutControlItem7
        '
        Me.LayoutControlItem7.Control = Me.ZVS3_CheckEdit
        Me.LayoutControlItem7.Location = New System.Drawing.Point(0, 245)
        Me.LayoutControlItem7.Name = "LayoutControlItem7"
        Me.LayoutControlItem7.Size = New System.Drawing.Size(561, 22)
        Me.LayoutControlItem7.TextSize = New System.Drawing.Size(0, 0)
        Me.LayoutControlItem7.TextVisible = False
        '
        'LayoutControlItem8
        '
        Me.LayoutControlItem8.Control = Me.ZVS41_CheckEdit
        Me.LayoutControlItem8.Location = New System.Drawing.Point(0, 267)
        Me.LayoutControlItem8.Name = "LayoutControlItem8"
        Me.LayoutControlItem8.Size = New System.Drawing.Size(561, 22)
        Me.LayoutControlItem8.TextSize = New System.Drawing.Size(0, 0)
        Me.LayoutControlItem8.TextVisible = False
        '
        'LayoutControlItem9
        '
        Me.LayoutControlItem9.Control = Me.ZVS42_CheckEdit
        Me.LayoutControlItem9.Location = New System.Drawing.Point(0, 289)
        Me.LayoutControlItem9.Name = "LayoutControlItem9"
        Me.LayoutControlItem9.Size = New System.Drawing.Size(561, 22)
        Me.LayoutControlItem9.TextSize = New System.Drawing.Size(0, 0)
        Me.LayoutControlItem9.TextVisible = False
        '
        'LayoutControlItem10
        '
        Me.LayoutControlItem10.Control = Me.ZVS52_CheckEdit
        Me.LayoutControlItem10.Location = New System.Drawing.Point(0, 333)
        Me.LayoutControlItem10.Name = "LayoutControlItem10"
        Me.LayoutControlItem10.Size = New System.Drawing.Size(561, 22)
        Me.LayoutControlItem10.TextSize = New System.Drawing.Size(0, 0)
        Me.LayoutControlItem10.TextVisible = False
        '
        'LayoutControlItem11
        '
        Me.LayoutControlItem11.Control = Me.SelectAll_btn
        Me.LayoutControlItem11.Location = New System.Drawing.Point(0, 377)
        Me.LayoutControlItem11.Name = "LayoutControlItem11"
        Me.LayoutControlItem11.Size = New System.Drawing.Size(291, 26)
        Me.LayoutControlItem11.TextSize = New System.Drawing.Size(0, 0)
        Me.LayoutControlItem11.TextVisible = False
        '
        'LayoutControlItem12
        '
        Me.LayoutControlItem12.Control = Me.ClearAll_btn
        Me.LayoutControlItem12.Location = New System.Drawing.Point(291, 377)
        Me.LayoutControlItem12.Name = "LayoutControlItem12"
        Me.LayoutControlItem12.Size = New System.Drawing.Size(270, 26)
        Me.LayoutControlItem12.TextSize = New System.Drawing.Size(0, 0)
        Me.LayoutControlItem12.TextVisible = False
        '
        'LayoutControlItem14
        '
        Me.LayoutControlItem14.Control = Me.ZVS51_CheckEdit
        Me.LayoutControlItem14.ControlAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.LayoutControlItem14.CustomizationFormText = "LayoutControlItem10"
        Me.LayoutControlItem14.Location = New System.Drawing.Point(0, 311)
        Me.LayoutControlItem14.Name = "LayoutControlItem14"
        Me.LayoutControlItem14.Size = New System.Drawing.Size(561, 22)
        Me.LayoutControlItem14.Text = "LayoutControlItem10"
        Me.LayoutControlItem14.TextSize = New System.Drawing.Size(0, 0)
        Me.LayoutControlItem14.TextVisible = False
        '
        'LayoutControlItem13
        '
        Me.LayoutControlItem13.Control = Me.ZVS6_CheckEdit
        Me.LayoutControlItem13.ControlAlignment = System.Drawing.ContentAlignment.TopLeft
        Me.LayoutControlItem13.CustomizationFormText = "LayoutControlItem10"
        Me.LayoutControlItem13.Location = New System.Drawing.Point(0, 355)
        Me.LayoutControlItem13.Name = "LayoutControlItem13"
        Me.LayoutControlItem13.Size = New System.Drawing.Size(561, 22)
        Me.LayoutControlItem13.Text = "LayoutControlItem10"
        Me.LayoutControlItem13.TextSize = New System.Drawing.Size(0, 0)
        Me.LayoutControlItem13.TextVisible = False
        '
        'ReportingDate_BarEditItem
        '
        Me.ReportingDate_BarEditItem.Caption = "Reporting Date"
        Me.ReportingDate_BarEditItem.Edit = Nothing
        Me.ReportingDate_BarEditItem.EditWidth = 160
        Me.ReportingDate_BarEditItem.Id = 4
        Me.ReportingDate_BarEditItem.ImageOptions.Image = CType(resources.GetObject("ReportingDate_BarEditItem.ImageOptions.Image"), System.Drawing.Image)
        Me.ReportingDate_BarEditItem.ImageOptions.LargeImage = CType(resources.GetObject("ReportingDate_BarEditItem.ImageOptions.LargeImage"), System.Drawing.Image)
        Me.ReportingDate_BarEditItem.ItemAppearance.Normal.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReportingDate_BarEditItem.ItemAppearance.Normal.Options.UseFont = True
        Me.ReportingDate_BarEditItem.Name = "ReportingDate_BarEditItem"
        '
        'BarEditItem1
        '
        Me.BarEditItem1.Caption = "Reporting Date"
        Me.BarEditItem1.Edit = Nothing
        Me.BarEditItem1.EditWidth = 160
        Me.BarEditItem1.Id = 4
        Me.BarEditItem1.ImageOptions.Image = CType(resources.GetObject("BarEditItem1.ImageOptions.Image"), System.Drawing.Image)
        Me.BarEditItem1.ImageOptions.LargeImage = CType(resources.GetObject("BarEditItem1.ImageOptions.LargeImage"), System.Drawing.Image)
        Me.BarEditItem1.ItemAppearance.Normal.Font = New System.Drawing.Font("Calibri", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BarEditItem1.ItemAppearance.Normal.Options.UseFont = True
        Me.BarEditItem1.Name = "BarEditItem1"
        '
        'ZvStatistic_XmlCreation2022_H
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.Controls.Add(Me.AbacusFilesRecreationLayoutControl1ConvertedLayout)
        Me.Name = "ZvStatistic_XmlCreation2022_H"
        Me.Size = New System.Drawing.Size(579, 460)
        CType(Me.AbacusFilesRecreationLayoutControl1ConvertedLayout, System.ComponentModel.ISupportInitialize).EndInit()
        Me.AbacusFilesRecreationLayoutControl1ConvertedLayout.ResumeLayout(False)
        CType(Me.ZVS52_CheckEdit.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ZVS42_CheckEdit.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ZVS41_CheckEdit.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ZVS3_CheckEdit.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ZVS2_CheckEdit.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ZVS1_CheckEdit.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureEdit1.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ZvMeldeschemas_SearchLookUpEdit.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ZvMeldeperiod_ComboboxEdit.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ZvMeldejahr_DateEdit.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ZVS6_CheckEdit.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ZVS51_CheckEdit.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LayoutControlGroup1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.SearchLookUpEdit1item, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LayoutControlItem1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LayoutControlItem2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LayoutControlItem4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LayoutControlItem3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LayoutControlItem5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LayoutControlItem6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LayoutControlItem7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LayoutControlItem8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LayoutControlItem9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LayoutControlItem10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LayoutControlItem11, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LayoutControlItem12, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LayoutControlItem14, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LayoutControlItem13, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents ReportingDate_BarEditItem As DevExpress.XtraBars.BarEditItem
    Friend WithEvents BarEditItem1 As DevExpress.XtraBars.BarEditItem
    Friend WithEvents AbacusFilesRecreationLayoutControl1ConvertedLayout As DevExpress.XtraLayout.LayoutControl
    Friend WithEvents LayoutControlGroup1 As DevExpress.XtraLayout.LayoutControlGroup
    Friend WithEvents SearchLookUpEdit1item As DevExpress.XtraLayout.LayoutControlItem
    Friend WithEvents ProgressPanel1 As DevExpress.XtraWaitForm.ProgressPanel
    Friend WithEvents LayoutControlItem1 As DevExpress.XtraLayout.LayoutControlItem
    Friend WithEvents PictureEdit1 As DevExpress.XtraEditors.PictureEdit
    Friend WithEvents LayoutControlItem2 As DevExpress.XtraLayout.LayoutControlItem
    Friend WithEvents LayoutControlItem4 As DevExpress.XtraLayout.LayoutControlItem
    Friend WithEvents LayoutControlItem3 As DevExpress.XtraLayout.LayoutControlItem
    Friend WithEvents ZVS52_CheckEdit As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents ZVS42_CheckEdit As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents ZVS41_CheckEdit As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents ZVS3_CheckEdit As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents ZVS2_CheckEdit As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents ZVS1_CheckEdit As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents LayoutControlItem5 As DevExpress.XtraLayout.LayoutControlItem
    Friend WithEvents LayoutControlItem6 As DevExpress.XtraLayout.LayoutControlItem
    Friend WithEvents LayoutControlItem7 As DevExpress.XtraLayout.LayoutControlItem
    Friend WithEvents LayoutControlItem8 As DevExpress.XtraLayout.LayoutControlItem
    Friend WithEvents LayoutControlItem9 As DevExpress.XtraLayout.LayoutControlItem
    Friend WithEvents LayoutControlItem10 As DevExpress.XtraLayout.LayoutControlItem
    Friend WithEvents ZvMeldeschemas_SearchLookUpEdit As DevExpress.XtraEditors.TextEdit
    Friend WithEvents ZvMeldeperiod_ComboboxEdit As DevExpress.XtraEditors.TextEdit
    Friend WithEvents ZvMeldejahr_DateEdit As DevExpress.XtraEditors.TextEdit
    Friend WithEvents ClearAll_btn As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents SelectAll_btn As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents LayoutControlItem11 As DevExpress.XtraLayout.LayoutControlItem
    Friend WithEvents LayoutControlItem12 As DevExpress.XtraLayout.LayoutControlItem
    Friend WithEvents ZVS6_CheckEdit As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents ZVS51_CheckEdit As DevExpress.XtraEditors.CheckEdit
    Friend WithEvents LayoutControlItem13 As DevExpress.XtraLayout.LayoutControlItem
    Friend WithEvents LayoutControlItem14 As DevExpress.XtraLayout.LayoutControlItem
End Class
